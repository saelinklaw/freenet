package freenet.clients.fcp;

public enum DataSource {
	DIRECT,
	DISK
}
