/** Bookmark management code. FProxy maintains a list of "bookmarks", freesites which we show on 
 * the welcome page and subscribe to updates for so they will load the latest version quickly. */
package freenet.clients.http.bookmark;