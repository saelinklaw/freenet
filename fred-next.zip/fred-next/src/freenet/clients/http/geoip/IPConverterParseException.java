package freenet.clients.http.geoip;

public class IPConverterParseException extends Exception {
    static final long serialVersionUID = 8465371657927636643L;
}
