package freenet.client.async;

public class NoValidBlocksException extends Exception {

   final private static long serialVersionUID = 1056057448877395180L;

}
