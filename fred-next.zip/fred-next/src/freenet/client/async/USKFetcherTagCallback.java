package freenet.client.async;

public interface USKFetcherTagCallback extends USKFetcherCallback {
	
	public void setTag(USKFetcherTag tag, ClientContext context);

}
