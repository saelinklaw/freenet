package freenet.client.async;

public class PersistenceDisabledException extends Exception {
    private static final long serialVersionUID = -992316133570818146L;
}
