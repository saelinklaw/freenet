package freenet.client.filter;

public enum FilterOperation {
	READ,
	WRITE,
	BOTH
}
