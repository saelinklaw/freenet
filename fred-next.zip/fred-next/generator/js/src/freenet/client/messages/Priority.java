package freenet.client.messages;

/** Priority */
public enum Priority {
	MINOR, WARNING, ERROR, CRITICAL;

}
