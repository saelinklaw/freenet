package freenet;

public enum Type {
	INTEGRATION,ACCEPTANCE
}
