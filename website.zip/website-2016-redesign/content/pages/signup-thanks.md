---
title: Thank you
url: 
status: hidden
save_as: signup-thanks.html
---

Thank you for signing up for the Freenet Announcement Mailing List.
You should receive a confirmation email shortly from no-reply@freenetproject.org.
