---
title: "Weekend of Code" hackathon announcement
date: 2015-11-20
layout: content
---

## Who?

We welcome developers of all skill levels, designers, translators, and users.

## What?

The Freenet Project is holding a "Weekend of Code" hackathon to improve user experience.

## When?

The weekend of December 19th and 20th.

## Where?

[chat.freenode.net #freenet][irc_url]

[FLIP][flip_url] #freenet

Local meetups are arranged separately.

## Details

See the [wiki Hackathon page][hackathon_url] for details.

Happy hacking!

[irc_url]: help.html#irc
[flip_url]: https://wiki.freenetproject.org/FLIP
[hackathon_url]: https://wiki.freenetproject.org/Wiki/Hackathon
