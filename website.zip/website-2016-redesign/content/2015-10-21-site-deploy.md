---
title: Website redesign is live
date: 2015-10-21
layout: content
---

The redesigned website is now live!
Existing URLs [redirect](http://www.w3.org/Provider/Style/URI.html)
to their new equivalents. Thanks to everyone who contributed feedback,
development, and translations.

If we missed something, please tell us in our [support chat](help.html#irc)!
