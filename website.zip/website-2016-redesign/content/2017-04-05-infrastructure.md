---
layout: content
title:  Freenet infrastructure changes
date:   2017-04-05
categories: news
---
We have to do infrastructure changes. This will bring some (hopefully short-term) breakage to the website. Please bear with us. Freenet itself (the network) should be unaffected.
