---
layout: content
title:  DuckDuckGo donated $25,000
date:   2016-05-03
categories: news
---
The Freenet Project is very excited to announce that [DuckDuckGo have donated][ddg_url] $25,000 to our project.
This new funding will be used to advance our goal of ensuring true freedom of communication on the Internet.

The project has always operated in a democratic manner, and we will use an open process to set priorities for how we allocate this funding, which will incorporate the views of Freenet’s users, developers, and supporters.

[ddg_url]: https://duck.co/blog/post/303/2016-foss-donations-announcement
